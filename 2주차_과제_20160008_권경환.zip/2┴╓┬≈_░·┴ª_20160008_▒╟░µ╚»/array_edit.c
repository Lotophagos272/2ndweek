#include "star.h"

void edoarray(long thedigit, long* oarray){
long itera;
long tempr;
	for(itera=0;itera<10;itera++){
		if (thedigit==itera){
			tempr=oarray[itera]+1;
			oarray[itera]=tempr;}
	}
return;
}


void prntoarray(long* oarray){
int iter;
for(iter=0;iter<10;iter++){
	printf("%ld ", (long) oarray[iter]);
}
printf("\n");
return;
}

void froarray(long* oarray){
int ite;
for(ite=0;ite<10;ite++){
	oarray[ite]=0;
}
return;
}
