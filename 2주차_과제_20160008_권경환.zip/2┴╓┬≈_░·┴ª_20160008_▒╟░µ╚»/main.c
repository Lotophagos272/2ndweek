#include "star.h"


int main(){

long oarray[10]={0};

int count_test;
scanf("%d", &count_test);
long* pages;
pages=(long*)malloc((sizeof(long))*count_test);

int i;
long temp;
/*
for(i=0; i < count_test; i++){
	scanf("%ld", &temp);
	pages[i]=temp;
}
*/


for (i=0;i<count_test;i++){
	long page=1;
	long dec=1;
	scanf("%ld", &temp);
	pages[i]=temp;
	for (page=1;page <= pages[i];page++){
		while(1){
			if(page < dec*10){
				break;}
			else {
				dec=dec*10;}
		}
		pagenums(page, dec, oarray);		
	}
	prntoarray(oarray);
	froarray(oarray);
}

return 0;
}
