#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>




void pagenums(long page, long dec, long* oarray);
void edoarray(long thedigit, long* oarray);
void prntoarray(long* oarray);
void froarray(long* oarray);
